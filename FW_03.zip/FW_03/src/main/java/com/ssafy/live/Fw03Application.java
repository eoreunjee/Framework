package com.ssafy.live;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fw03Application {

	public static void main(String[] args) {
		SpringApplication.run(Fw03Application.class, args);
	}

}
